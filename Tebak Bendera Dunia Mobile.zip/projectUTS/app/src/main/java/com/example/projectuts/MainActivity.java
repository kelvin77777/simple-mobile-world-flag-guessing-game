package com.example.projectuts;
import android.content.Intent;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView ivShowImage, ivShowImageHP1, ivShowImageHP2, ivShowImageHP3;
    ImageView ivShowImageHPH1, ivShowImageHPH2, ivShowImageHPH3;
    ArrayList<String> countryNames = new ArrayList<>();
    ArrayList<String> newCountryNames = new ArrayList<>();
    HashMap<String, String> map = new HashMap<>();
    int index;
    Random random;
    String[] answers = new String[4];
    Button btn1, btn2, btn3, btn4;
    public static int points = 0;
    int wrongPoints = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivShowImage = findViewById(R.id.ivShowImage);
        ivShowImageHP1 = findViewById(R.id.hpShow1);
        ivShowImageHP2 = findViewById(R.id.hpShow2);
        ivShowImageHP3 = findViewById(R.id.hpShow3);
        ivShowImageHPH1 = findViewById(R.id.hpShow1);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        countryNames.add("Austria");
        countryNames.add("Barbados");
        countryNames.add("Belgium");
        countryNames.add("Democratic Peoples Republic of Korea");
        countryNames.add("Germany");
        countryNames.add("New Zealand");
        countryNames.add("Great Britain");


        index = 0;
        map.put(countryNames.get(0), String.valueOf(R.drawable.aust));
        map.put(countryNames.get(1), String.valueOf(R.drawable.bd));
        map.put(countryNames.get(2), String.valueOf(R.drawable.bel));
        map.put(countryNames.get(3), String.valueOf(R.drawable.dprk));
        map.put(countryNames.get(4), String.valueOf(R.drawable.ger));
        map.put(countryNames.get(5), String.valueOf(R.drawable.nz));
        map.put(countryNames.get(6), String.valueOf(R.drawable.uk));
        Collections.shuffle(countryNames);
        random = new Random();
        generateQuestions(index);
    }

    private void generateQuestions(int index) {
        int resourceId = getResources().getIdentifier(map.get(countryNames.get(index)), "drawable", getPackageName());
        Glide.with(this)
                .asBitmap()
                .load(resourceId)
                .error(R.drawable.not_found)
                .into(ivShowImage);
        newCountryNames = (ArrayList<String>) countryNames.clone();
        newCountryNames.remove(index);
        Collections.shuffle(newCountryNames);
        int correctAnswerPosition = random.nextInt(4);
        for(int i=0;i<4;i++){
            if(i == correctAnswerPosition) {
                answers[i] = countryNames.get(index);
            }else {
                answers[i] = newCountryNames.get(i);
            }
        }
        btn1.setText(answers[0]);
        btn2.setText(answers[1]);
        btn3.setText(answers[2]);
        btn4.setText(answers[3]);
    }



    public void answerSelected(View view) {
        String answer = ((Button) view).getText().toString();
        if(answer.equals(countryNames.get(index))){
            points++;
        }else {
            Toast.makeText(this, "Jawaban anda salah", Toast.LENGTH_SHORT).show();
            wrongPoints++;
            if(wrongPoints == 1) {
                ivShowImageHP1.setVisibility(View.GONE);
            }else if(wrongPoints == 2){
                ivShowImageHP2.setVisibility(View.GONE);
            }else if(wrongPoints == 3) {
                ivShowImageHP3.setVisibility(View.GONE);
                Intent in = new Intent(this, gameOver.class);
                startActivity(in);
            }
        }
        index++;
        if(index > countryNames.size() - 1){

            ivShowImage.setVisibility(View.GONE);
            btn1.setVisibility(View.GONE);
            btn2.setVisibility(View.GONE);
            btn3.setVisibility(View.GONE);
            btn4.setVisibility(View.GONE);
        }else {
            generateQuestions(index);
        }

        if(index == 7) {
            Intent in = new Intent(this, WinnerActivity.class);
            startActivity(in);
        }
    }



}