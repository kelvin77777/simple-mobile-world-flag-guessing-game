package com.example.projectuts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
public class StartActivity extends AppCompatActivity {
    Button btnMulai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        btnMulai = (Button) findViewById(R.id.buttonmulai);
        btnMulai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tampilKuis(view);
            }
        });
    }
    public void tampilKuis(View v) {
        Intent in = new Intent(this, MainActivity.class);
        startActivity(in);
    }

}