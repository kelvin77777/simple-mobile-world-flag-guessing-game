package com.example.projectuts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class WinnerActivity extends AppCompatActivity {
    int index;
    TextView tvPoint;
    ImageView finalHP1, finalHP2, finalHP3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);

        tvPoint = findViewById(R.id.tvPoints);
        finalHP1 = findViewById(R.id.hpWin1);
        finalHP2 = findViewById(R.id.hpWin2);
        finalHP3 = findViewById(R.id.hpWin3);

        final int finalPoints = MainActivity.points;
        tvPoint.setText("Points: "+finalPoints+ "/7");

        if(finalPoints == 6) {
            finalHP3.setVisibility(View.GONE);
        }else if(finalPoints == 5) {
            finalHP3.setVisibility(View.GONE);
            finalHP2.setVisibility(View.GONE);
        }


    }
    public void BackHome(View v) {
        Intent in = new Intent(this, StartActivity.class);
        startActivity(in);
    }
}